--BULK INSERT A1704007.[Materiales]
--   FROM 'e:\wwwroot\rcortese\materiales.csv'
--   WITH 
--      (                                                       -- Llena masivamente tabla Materiales
--        CODEPAGE = 'ACP',
--        FIELDTERMINATOR = ',',
--        ROWTERMINATOR = '\n'
--      )

BULK INSERT A1704007.[Materiales]
   FROM 'e:\wwwroot\rcortese\materiales.csv'
   WITH 
      (
        CODEPAGE = 'ACP',
        FIELDTERMINATOR = ',',
        ROWTERMINATOR = '\n'
      )

BULK INSERT A1704007.[Proveedores]
   FROM 'e:\wwwroot\rcortese\proveedores.csv'
   WITH 
      (
        CODEPAGE = 'ACP',
        FIELDTERMINATOR = ',',
        ROWTERMINATOR = '\n'
      )

BULK INSERT A1704007.[Proyectos]
   FROM 'e:\wwwroot\rcortese\proyectos.csv'
   WITH 
      (
        CODEPAGE = 'ACP',
        FIELDTERMINATOR = ',',
        ROWTERMINATOR = '\n'
      )

BULK INSERT A1704007.[Entregan]
   FROM 'e:\wwwroot\rcortese\entregan.csv'
   WITH 
      (
        CODEPAGE = 'ACP',
        FIELDTERMINATOR = ',',
        ROWTERMINATOR = '\n'
      )
SET DATEFORMAT dmy                                                  -- Cambia formato de fecha


SELECT  * FROM Materiales                                           -- Muestra tabla de Materiales
SELECT  * FROM Proveedores                                          -- Muestra tabla de Proveedores
SELECT  * FROM Proyectos                                            -- Muestra tabla de Proyectos
SELECT  * FROM Entregan                                             -- Muestra tabla de Entregan

--¿Qué relación tiene el contenido de este archivo (materiales.sql) con el formato en que se encuentran los datos en el archivo materiales.csv?
--Tiene Clave, descripcion, y costo los dos.

--¿Qué sucedió?
--Con el SELECT, despliego las tablas con sus atributos e informacion de cada atributo ordenadamente.