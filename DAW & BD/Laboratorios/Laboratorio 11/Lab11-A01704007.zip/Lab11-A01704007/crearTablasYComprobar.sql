-- NOTA: Puse todo en el mismo query pero ejecute seleccionando cada una de las lineas que queria ejecutar.

CREATE TABLE Materiales                     -- Crea Tabla Materiales con sus atributos
(
  Clave numeric(5),
  Descripcion varchar(50),
  Costo numeric(8,2)
)

CREATE TABLE Proveedores                    -- Crea Tabla Proveedores con sus atributos
(
  RFC char(13),
  RazonSocial varchar(50),
)

CREATE TABLE Proyectos                      -- Crea Tabla Proyectos con sus atributos
(
  Numero numeric(5),
  Denominacion varchar(50),
)

CREATE TABLE Entregan                       -- Crea Tabla Entregan con sus atributos
(
  Clave numeric(5),
  RFC char(13),
  Numero numeric(5),
  Fecha DATETIME,
  Cantidad numeric(8,2)
)
--sp_help Materiales                        -- Muestra tabla Materiales
--sp_help Proveedores                       -- Muestra tabla Proveedores
--sp_help Proyectos                         -- Muestra tabla Proyectos
--sp_help Entregan                          -- Muestra tabla Entregan

--drop table Materiales                     -- Borra tabla Materiales
--drop table Proveedores                    -- Borra tabla Proveedores
--drop table Proyectos                       -- Borra tabla Proyecto
--drop table Entregan                       -- Borra tabla Entrega

select * from sysobjects where xtype='U'  -- Muestra tablas existentes


--¿Qué efecto tuvo esta acción? Pues como lo deje, crea las tablas correspondientes con sus atributos

--¿Qué utilidad tiene esta manera de ejecutar los comandos de SQL? Super sencillo de usar, y practico para consultar informacion rapidamente